﻿namespace WA.Models
{
    public class SensorData
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public float Value { get; set; }
        public DateTime ReceiveTime { get; set; }
    }
}
